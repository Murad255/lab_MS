# Kinematics control

Small notebooks dedicated to kinematic control in industrial robotics.
